<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });


Route::get('/','PagesController@home'); 
Route::get('/about','PagesController@about');

Route::get('/laporan','LaporanController@index');

#reports
Route::get('/reports','ReportsController@index');
Route::get('/reports/create','ReportsController@create');
Route::get('/reports/{report}','ReportsController@show');
Route::POST('/reports','ReportsController@store');
Route::delete('/reports/{report}','ReportsController@destroy');
Route::get('/reports/{report}/edit','ReportsController@edit');
Route::patch('/reports/{report}','ReportsController@update');