<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    protected $fillable=['kategori','lampiran','deskripsi','tindakan','created_at'];

}
