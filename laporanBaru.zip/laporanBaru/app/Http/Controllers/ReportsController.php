<?php

namespace App\Http\Controllers;

use App\Report;
use Illuminate\Http\Request;

class ReportsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reports = Report::all();
        return view('reports/index',compact('reports'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('reports/create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'kategori' => 'required',
            'lampiran' => 'required',
            'deskripsi'=> 'required',
            // 'tanggal_dibuat'=> 'required',
            'tindakan'=> 'required'
        ]);


        Report::create($request->all());
        return redirect('/reports')->with('status','Laporan Berhasil Ditambahkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Report  $report
     * @return \Illuminate\Http\Response
     */
    public function show(Report $report)
    {
        return view('reports/show', compact('report'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Report  $report
     * @return \Illuminate\Http\Response
     */
    public function edit(Report $report)
    {
        return view('reports.edit',compact('report'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Report  $report
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Report $report)
    {
        $request->validate([
            'kategori' => 'required',
            'lampiran' => 'required',
            'deskripsi'=> 'required',
            // 'tanggal_dibuat'=> 'required',
            'tindakan'=> 'required'
        ]);
        Report::where('id',$report->id)
            ->update([
                'kategori'=> $request->kategori,
                'lampiran'=> $request->lampiran,
                'deskripsi'=> $request->deskripsi,
                // 'tanggal_dibuat'=> $request->tanggal_dibuat,
                'tindakan'=> $request->tindakan,
            ]);
            return redirect('/reports')->with('status','Laporan Berhasil
            diEdit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Report  $report
     * @return \Illuminate\Http\Response
     */
    public function destroy(Report $report)
    {
        Report::destroy($report->id);
        return redirect('/reports')->with('status','Laporan Berhasil
        Dihapus');
    }
}
