@extends('layout/main')

{{-- @section('title','Form Laporan') --}}

@section('container')

<div class="container">
    <div class="row">
        <div class="col-8">
            <h1 class="mt-3">Form Laporan</h1>
              <form method="POST" action="/reports">
                @csrf
                  {{-- <div class="form-group">
                      <label for="kategori">kategori</label>
                        <input type="text" 
                            class="form-control @error('kategori') is-invalid @enderror" 
                                id="kategori" placeholder="Masukkan kategori" name="kategori" value="{{ old('kategori') }}">
                                    @error('kategori')
                                        <div 
                                            class="invalid-feedback">{{$message}}
                                        </div>
                                    @enderror
                  </div> --}}
                  <div class="form-group">
                        <label for="kategori">kategori</label>
                            <select id="kategori" placeholder="Masukan kategori" class="form-control" name="kategori"  >
                                <option value="" disabled selected hidden>Masukan Kategori</option>
                                <option>Keamanan</option>
                                <option>Kebersihan</option>
                                <option>Fasilitas Umum</option>
                            </select>
                        </div>
                        {{-- <form>
                                <div class="form-group">
                                  <label for="lampiran">Example file input</label>
                                  <input type="file" class="form-control-file" id="lampiran" name="lampiran">
                                </div>
                              </form> --}}
                  <div class="form-group">
                      <label for="lampiran">lampiran</label>
                        <input type="text" 
                            class="form-control @error('lampiran') is-invalid @enderror" 
                                id="lampiran" placeholder="Masukkan lampiran" name="lampiran" value="{{ old('lampiran') }}">
                                    @error('lampiran')
                                        <div 
                                            class="invalid-feedback">{{$message}}
                                        </div>
                                    @enderror
                  </div>
                  <div class="form-group">
                      <label for="deskripsi">deskripsi</label>
                        <input type="text" 
                            class="form-control @error('deskripsi') is-invalid @enderror" 
                                id="deskripsi" placeholder="Masukkan deskripsi" name="deskripsi" value="{{ old('deskripsi') }}">
                                    @error('deskripsi')
                                        <div 
                                            class="invalid-feedback">{{$message}}
                                        </div>
                                    @enderror
                  </div>
                  <div class="form-group">
                      <label for="tindakan">tindakan</label>
                        <input type="text" 
                            class="form-control @error('tindakan') is-invalid @enderror" 
                                id="tindakan" placeholder=" tindakan" name="tindakan" value="{{ old('tindakan') }}">
                                    @error('tindakan')
                                        <div 
                                            class="invalid-feedback">{{$message}}
                                        </div>
                                    @enderror
                  </div>
                  <button type="submit" class="btn btn-primary">Tambah Data!</button>
                </form>
        </div>
    </div>
</div>
@endsection 