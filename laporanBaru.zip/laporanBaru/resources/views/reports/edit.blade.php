@extends('layout/main')

@section('title','Form Edit Laporan')

@section('container')

<div class="container">
    <div class="row">
        <div class="col-8">
            <h1 class="mt-3">Form Edit Laporan</h1>
        <form method="POST" action="/reports/{{ $report->id}}">
            @method('patch')      
                @csrf
                  <div class="form-group">
                      <label for="kategori">kategori</label>
                        <input type="text" 
                            class="form-control @error('kategori') is-invalid @enderror" 
                                id="kategori" placeholder="Masukkan kategori" name="kategori" value="{{ $report->kategori }}">
                                    @error('kategori')
                                        <div 
                                            class="invalid-feedback">{{$message}}
                                        </div>
                                    @enderror
                  </div>
                  <div class="form-group">
                      <label for="lampiran">lampiran</label>
                        <input type="text" 
                            class="form-control @error('lampiran') is-invalid @enderror" 
                                id="lampiran" placeholder="Masukkan lampiran" name="lampiran" value="{{ $report->lampiran }}">
                                    @error('lampiran')
                                        <div 
                                            class="invalid-feedback">{{$message}}
                                        </div>
                                    @enderror
                  </div>
                  <div class="form-group">
                      <label for="deskripsi">deskripsi</label>
                        <input type="text" 
                            class="form-control @error('deskripsi') is-invalid @enderror" 
                                id="deskripsi" placeholder="Masukkan deskripsi" name="deskripsi" value="{{ $report->deskripsi }}">
                                    @error('deskripsi')
                                        <div 
                                            class="invalid-feedback">{{$message}}
                                        </div>
                                    @enderror
                  </div>
                  <div class="form-group">
                      <label for="tindakan">tindakan</label>
                        <input type="text" 
                            class="form-control @error('tindakan') is-invalid @enderror" 
                                id="tindakan" placeholder=" tindakan" name="tindakan" value="{{ $report->tindakan }}">
                                    @error('tindakan')
                                        <div 
                                            class="invalid-feedback">{{$message}}
                                        </div>
                                    @enderror
                  </div>
                  {{-- <div class="form-group">
                    <label for="jurusan">Jurusan</label>
                        <select id="jurusan" class="form-control" name="jurusan">
                            <option>Choose...</option>
                            <option>Teknik Informatika</option>
                            <option>Teknik Industri</option>
                            <option>Teknik Kimia</option>
                            <option>Teknik Mesin</option>
                            <option>Teknik Elektro</option>
                        </select>
                    </div> --}}
                
                  <button type="submit" class="btn btn-primary">Tambah Data!</button>
                </form>
        </div>
    </div>
</div>
@endsection 