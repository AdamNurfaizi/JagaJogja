{{-- @extends('layout.main')

@section('title','Daftar Mahasiswa')

@section('container')
<div class="container">
    <div class="row">
        <div class="col-6">
            <h1 class="mt-3">Daftar Mahasiswa</h1>
            <a href="/reports/create" class="btn btn-primary my-3">Buat Laporan</a>
            @if (session('status'))
                            <div class="alert alert-success">
                                {{ session('status')}}
                            </div>
                        @endif
            <ul class="list-group">
                @foreach ($reports as $report)         
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        {{ $report->kategori}}
                        <a href="/reports/{{ $report->id}}" class="badge badge-info">detail</a>
                    </li>
                @endforeach
            </ul>
        </div>
    </div>
</div>
@endsection --}}

@extends('layout/main')

{{-- @section('title','Laporan') --}}

@section('container')
    
    <!-- Page Header -->
    <header class="masthead">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="site-heading">
              <h1></h1>
              {{-- <span class="subheading">A Blog Theme by Start Bootstrap</span> --}}
            </div>
          </div>
        </div>
      </div>
    </header>
  
    <!-- Main Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 ">
          <div class="post-preview">
            {{-- <a href="post.html"> --}}
              {{-- <h2 class="post-title">
                Tentang Jaga Jogja
              </h2> --}}
              <div class="col-14">
                <h1 class="mt-10">Laporan Anda</h1>
                {{-- <a href="/reports/create" class="btn btn-primary my-3">Buat Laporan</a> --}}
                @if (session('status'))
                                <div class="alert alert-success">
                                    {{ session('status')}}
                                </div>
                            @endif
                <ul class="list-group">
                    @foreach ($reports as $report)         
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            {{ $report->kategori}}
                            <a href="/reports/{{ $report->id}}" class="badge badge-info">detail</a>
                        </li>
                    @endforeach
                </ul>
            </div>
              {{-- <h4 class="post-subtitle">
                Problems look mighty small from 150 miles up
              </h4> --}}
            </a>
           
          </div>
          
          <!-- Pager -->
          <div class="clearfix">
            {{-- <a class="btn btn-primary float-right" href="#">Older Posts &rarr;</a> --}}
          </div>
        </div>
      </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-8">
                <h1 class="mt-3">Form Laporan</h1>
                  <form method="POST" action="/reports">
                    @csrf
                      {{-- <div class="form-group">
                          <label for="kategori">kategori</label>
                            <input type="text" 
                                class="form-control @error('kategori') is-invalid @enderror" 
                                    id="kategori" placeholder="Masukkan kategori" name="kategori" value="{{ old('kategori') }}">
                                        @error('kategori')
                                            <div 
                                                class="invalid-feedback">{{$message}}
                                            </div>
                                        @enderror
                      </div> --}}
                      <div class="form-group">
                            <label for="kategori">kategori</label>
                                <select id="kategori" placeholder="Masukan kategori" class="form-control" name="kategori"  >
                                    <option value="" disabled selected hidden>Masukan Kategori</option>
                                    <option>Keamanan</option>
                                    <option>Kebersihan</option>
                                    <option>Fasilitas Umum</option>
                                </select>
                            </div>
                            {{-- <form>
                                    <div class="form-group">
                                      <label for="lampiran">Masukan Foto</label>
                                      <input type="file" class="form-control-file" id="lampiran" name="lampiran">
                                    </div>
                                  </form> --}}
                      <div class="form-group">
                          <label for="lampiran">lampiran</label>
                            <input type="text" 
                                class="form-control @error('lampiran') is-invalid @enderror" 
                                    id="lampiran" placeholder="Masukkan lampiran" name="lampiran" value="{{ old('lampiran') }}">
                                        @error('lampiran')
                                            <div 
                                                class="invalid-feedback">{{$message}}
                                            </div>
                                        @enderror
                      </div>
                      {{-- <div class="form-group">
                          <label for="deskripsi">deskripsi</label>
                            <input type="text" 
                                class="form-control @error('deskripsi') is-invalid @enderror" 
                                    id="deskripsi" rows="3" placeholder="Masukkan deskripsi" name="deskripsi" value="{{ old('deskripsi') }}">
                                        @error('deskripsi')
                                            <div 
                                                class="invalid-feedback">{{$message}}
                                            </div>
                                        @enderror
                      </div> --}}
                      <div class="form-group">
                          <label for="deskripsi">Deskripsi</label>
                          <textarea class="form-control" id="Deskripsi" name="deskripsi" rows="3"></textarea>
                        </div>
                      {{-- <div class="form-group">
                          <label for="tindakan">tindakan</label>
                            <input type="text" 
                                class="form-control @error('tindakan') is-invalid @enderror" 
                                    id="tindakan" placeholder=" tindakan" name="tindakan" value="{{ old('tindakan') }}">
                                        @error('tindakan')
                                            <div 
                                                class="invalid-feedback">{{$message}}
                                            </div>
                                        @enderror
                      </div> --}}
                      <div class="form-group">
                          <label for="tindakan">tindakan</label>
                              <select id="tindakan" placeholder="Masukan tindakan" class="form-control" name="tindakan"  >
                                  <option value="" disabled selected hidden>Masukan tindakan</option>
                                  <option>belum diproses</option>
                                  <option>Sedang diproses</option>
                                  <option>Terselesaikan</option>
                              </select>
                          </div>
                          
                      <button type="submit" class="btn btn-primary">Tambah Data!</button>
                    </form>
            </div>
        </div>
    </div>
@endsection