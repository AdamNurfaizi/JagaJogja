{{-- @extends('layout/main')

@section('title','input nilai')

@section('container')
    
  <div class="container">
    <div class="row">
        <div class="col-10">
            <h1 class="mt-2">Hello, world!</h1>
        </div>
    </div>
  </div>
@endsection --}}

@extends('layout/main')

{{-- @section('title','Laporan') --}}

@section('container')
    <!-- Page Header -->
    <header class="masthead" style="background-image: url('img/tuguedit.jpg')">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="site-heading">
              <h1>Jaga Jogja</h1>
              <span class="subheading">Jaga Jogja adalah portal laporan keamanan, keberbesihan dan fasilitas umum
                untuk mewujudkan Jogja Smart City
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
    <div class="section" style="background-color: #F7F7F7;">
        <div class="container">
            <div class="row">
                
                <div class="col-md-6 col-md-pull-6">
                    <ul class="feature-list">
                        <li class="feature">
                            <div class="feature-icon" data-animation-name="rollIn" data-animation-delay="02s">
                                <span class="icon icon-lightbulb-o"></span>
                            </div>
                            <div class="feature-content" data-animation-name="fadeInLeft" data-animation-delay="02s">
                                <h2>Laporkan</h2>
                                <p>Warga dapat menyampaikan aspirasi dan pengaduan berupa keluhan, kritik dan saran kepada pemerintah Kabupaten Sleman</p>
                            </div>
                        </li>
                        <li class="feature">
                            <div class="feature-icon" data-animation-name="rollIn" data-animation-delay="02s">
                                <span class="icon icon-users"></span>
                            </div>
                            <div class="feature-content" data-animation-name="fadeInLeft" data-animation-delay="02s">
                                <h2>Kolaborasi</h2>
                                <p>Warga dan pemerintah Kabupaten Sleman bersama-sama berkolaborasi merespon dan menindaklanjuti segala aspirasi dan pengaduan warga</p>
                            </div>
                        </li>
                        <li class="feature">
                            <div class="feature-icon" data-animation-name="rollIn" data-animation-delay="01s">
                                <span class="icon icon-question"></span>
                            </div>
                            <div class="feature-content" data-animation-name="fadeInLeft" data-animation-delay="01s">
                                <h2>Pantau</h2>
                                <p>Pantau semua aspirasi dan pengaduan warga Sleman yang telah disampaikan</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <section>
        <div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <form class="bootstrap-form-with-validation">
                            <h2 class="text-center">Daftar disini!</h2>
                            <div class="form-group">
                                <label class="control-label" for="text-input"></label>
                                <input class="form-control" type="text" name="text-input" id="text-input" placeholder="Nama Lengkap">
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="email-input"></label>
                                <input class="form-control" type="email" name="email-input" id="email-input" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="password-input"></label>
                                <input class="form-control" type="password" name="password-input" id="password-input" placeholder="Password">
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="password-input"></label>
                                <input class="form-control" type="password" name="password-input" id="password-input" placeholder="Password Confirmation">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-success" type="submit">Daftar</button>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-12">
                        <h2 class="text-center">Masuk disini!</h2>
                        <div class="form-row align-items-center">
                            <div class="col-auto">
                              <label class="sr-only" for="inlineFormInput">Email</label>
                              <input type="text" class="form-control mb-2" id="inlineFormInput" placeholder="Email">
                            </div>
                            <div class="col-auto">
                              <label class="sr-only" for="inlineFormInputGroup" type="password">Password</label>
                              <div class="input-group mb-2">
                                <div class="input-group-prepend">
                                </div>
                                <input type="password" class="form-control" id="inlineFormInputGroup" placeholder="Password">
                              </div>
                            </div>
                            <div class="col-auto">
                              <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" id="autoSizingCheck">
                                <label class="form-check-label" for="autoSizingCheck">
                                  Remember me
                                </label>
                              </div>
                            </div>
                            <div class="form-group">
                                <form action="/reports">
                              <button type="submit" class="btn btn-success">Masuk</button>
                            </div>
                          </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
@endsection