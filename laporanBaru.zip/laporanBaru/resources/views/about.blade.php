@extends('layout/main')

{{-- @section('title','Laporan') --}}

@section('container')
    
    <!-- Page Header -->
    <header class="masthead" style="background-image: url('img/tugueditNEW.jpg')">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="site-heading">
              <h1>Tentang</h1>
              {{-- <span class="subheading">A Blog Theme by Start Bootstrap</span> --}}
            </div>
          </div>
        </div>
      </div>
    </header>
  
    <!-- Main Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="post-preview">
            {{-- <a href="post.html"> --}}
              <h2 class="post-title">
                Tentang Jaga Jogja
              </h2>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Turpis in eu mi bibendum neque egestas congue. Odio facilisis mauris sit amet massa vitae tortor condimentum. Tempor orci eu lobortis elementum nibh tellus molestie nunc non. Nisi vitae suscipit tellus mauris a diam. Morbi tincidunt augue interdum velit. Ut venenatis tellus in metus vulputate eu scelerisque felis. Lectus sit amet est placerat. Elementum nibh tellus molestie nunc non. Diam vel quam elementum pulvinar etiam. Gravida quis blandit turpis cursus in hac habitasse platea. Dictum fusce ut placerat orci nulla pellentesque dignissim. Turpis cursus in hac habitasse platea dictumst quisque. Aliquam faucibus purus in massa tempor nec feugiat. Tellus id interdum velit laoreet id donec ultrices. Facilisi morbi tempus iaculis urna. Ornare suspendisse sed nisi lacus sed viverra.

Senectus et netus et malesuada fames ac turpis egestas. Et malesuada fames ac turpis egestas sed. Consectetur libero id faucibus nisl tincidunt eget nullam non. Mi proin sed libero enim sed faucibus. Pellentesque dignissim enim sit amet venenatis urna cursus eget nunc. Massa sed elementum tempus egestas sed. Blandit massa enim nec dui nunc mattis enim. Tortor pretium viverra suspendisse potenti. In nisl nisi scelerisque eu ultrices vitae. Diam sit amet nisl suscipit. Felis eget velit aliquet sagittis id consectetur purus ut. Id velit ut tortor pretium viverra suspendisse. Integer feugiat scelerisque varius morbi. Fusce id velit ut tortor pretium viverra suspendisse potenti nullam. Quam viverra orci sagittis eu. Massa enim nec dui nunc.
              </p>
              {{-- <h4 class="post-subtitle">
                Problems look mighty small from 150 miles up
              </h4> --}}
            </a>
            <p class="post-meta">Posted by
              <a href="#">Start Bootstrap</a>
              on September 24, 2019</p>
          </div>
          
          <!-- Pager -->
          <div class="clearfix">
            {{-- <a class="btn btn-primary float-right" href="#">Older Posts &rarr;</a> --}}
          </div>
        </div>
      </div>
    </div>
    
@endsection