@extends('layout/main')

{{-- @section('title','Laporan') --}}

@section('container')
    
    <!-- Page Header -->
    <header class="masthead" style="background-image: url('img/tugueditNEW.jpg')">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="site-heading">
              <h1>Daftar Laporan</h1>
              {{-- <span class="subheading">A Blog Theme by Start Bootstrap</span> --}}
            </div>
          </div>
        </div>
      </div>
    </header>
    <div class="container">
    <div class="card" style="width: 18rem;">
        <img src="..." class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
      </div>
    </div> 

    <!-- Main Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-10 ">
          <div class="post-preview">
            {{-- <a href="post.html"> --}}
              <h2 class="post-title">
                Daftar Laporan
              </h2>
              <table class="table" style="">
                <thead class="thead-dark" style="background-color: #009640">
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Kategori</th>
                    <th scope="col">Lampiran</th>
                    <th scope="col">Deskripsi</th>
                    {{-- <th scope="col">Tanggal Dibuat</th> --}}
                    <th scope="col">Tindakan</th>
                    <th scope="col">Tanggal Dibuat</th>
                  </tr>
                </thead> 
                <tbody>
                    @foreach ($laporan as $lprn)
                    <tr>
                        <th scope="row">{{ $loop->iteration}}</th>
                        <td>{{ $lprn->kategori}}</td>
                        <td>{{ $lprn->lampiran}}</td>
                        <td>{{ $lprn->deskripsi}}</td>
                        {{-- <td>{{ $lprn->tanggal_dibuat}}</td> --}}
                        <td>{{ $lprn->tindakan}}</td>
                        <td>{{ $lprn->created_at}}</td>
                    </tr>
                     @endforeach
                </tbody>                 
              </table>
            </a>
          </div>
          <!-- Pager -->
          <div class="clearfix">
          </div>
        </div>
      </div>
    </div>
    
@endsection