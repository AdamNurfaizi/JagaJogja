<?php $__env->startSection('title','Form Edit Laporan'); ?>

<?php $__env->startSection('container'); ?>

<div class="container">
    <div class="row">
        <div class="col-8">
            <h1 class="mt-3">Form Edit Laporan</h1>
        <form method="POST" action="/reports/<?php echo e($report->id); ?>">
            <?php echo method_field('patch'); ?>      
                <?php echo csrf_field(); ?>
                  <div class="form-group">
                      <label for="kategori">kategori</label>
                        <input type="text" 
                            class="form-control <?php if ($errors->has('kategori')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                id="kategori" placeholder="Masukkan kategori" name="kategori" value="<?php echo e($report->kategori); ?>">
                                    <?php if ($errors->has('kategori')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori'); ?>
                                        <div 
                                            class="invalid-feedback"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                  <div class="form-group">
                      <label for="lampiran">lampiran</label>
                        <input type="text" 
                            class="form-control <?php if ($errors->has('lampiran')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lampiran'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                id="lampiran" placeholder="Masukkan lampiran" name="lampiran" value="<?php echo e($report->lampiran); ?>">
                                    <?php if ($errors->has('lampiran')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lampiran'); ?>
                                        <div 
                                            class="invalid-feedback"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                  <div class="form-group">
                      <label for="deskripsi">deskripsi</label>
                        <input type="text" 
                            class="form-control <?php if ($errors->has('deskripsi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deskripsi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                id="deskripsi" placeholder="Masukkan deskripsi" name="deskripsi" value="<?php echo e($report->deskripsi); ?>">
                                    <?php if ($errors->has('deskripsi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deskripsi'); ?>
                                        <div 
                                            class="invalid-feedback"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                  <div class="form-group">
                      <label for="tindakan">tindakan</label>
                        <input type="text" 
                            class="form-control <?php if ($errors->has('tindakan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tindakan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                id="tindakan" placeholder=" tindakan" name="tindakan" value="<?php echo e($report->tindakan); ?>">
                                    <?php if ($errors->has('tindakan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tindakan'); ?>
                                        <div 
                                            class="invalid-feedback"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                  
                
                  <button type="submit" class="btn btn-primary">Tambah Data!</button>
                </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laporanBaru/resources/views/reports/edit.blade.php ENDPATH**/ ?>