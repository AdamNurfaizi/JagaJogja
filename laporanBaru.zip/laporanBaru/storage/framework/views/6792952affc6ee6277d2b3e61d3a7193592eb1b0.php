<?php $__env->startSection('container'); ?>

<div class="container">
    <div class="row">
        <div class="col-8">
            <h1 class="mt-3">Form Laporan</h1>
              <form method="POST" action="/reports">
                <?php echo csrf_field(); ?>
                  
                  <div class="form-group">
                        <label for="kategori">kategori</label>
                            <select id="kategori" placeholder="Masukan kategori" class="form-control" name="kategori"  >
                                <option value="" disabled selected hidden>Masukan Kategori</option>
                                <option>Keamanan</option>
                                <option>Kebersihan</option>
                                <option>Fasilitas Umum</option>
                            </select>
                        </div>
                        
                  <div class="form-group">
                      <label for="lampiran">lampiran</label>
                        <input type="text" 
                            class="form-control <?php if ($errors->has('lampiran')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lampiran'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                id="lampiran" placeholder="Masukkan lampiran" name="lampiran" value="<?php echo e(old('lampiran')); ?>">
                                    <?php if ($errors->has('lampiran')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lampiran'); ?>
                                        <div 
                                            class="invalid-feedback"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                  <div class="form-group">
                      <label for="deskripsi">deskripsi</label>
                        <input type="text" 
                            class="form-control <?php if ($errors->has('deskripsi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deskripsi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                id="deskripsi" placeholder="Masukkan deskripsi" name="deskripsi" value="<?php echo e(old('deskripsi')); ?>">
                                    <?php if ($errors->has('deskripsi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deskripsi'); ?>
                                        <div 
                                            class="invalid-feedback"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                  <div class="form-group">
                      <label for="tindakan">tindakan</label>
                        <input type="text" 
                            class="form-control <?php if ($errors->has('tindakan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tindakan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                id="tindakan" placeholder=" tindakan" name="tindakan" value="<?php echo e(old('tindakan')); ?>">
                                    <?php if ($errors->has('tindakan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tindakan'); ?>
                                        <div 
                                            class="invalid-feedback"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                  <button type="submit" class="btn btn-primary">Tambah Data!</button>
                </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laporanBaru/resources/views/reports/create.blade.php ENDPATH**/ ?>