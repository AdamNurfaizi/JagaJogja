<?php $__env->startSection('container'); ?>
    
    <!-- Page Header -->
    <header class="masthead">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="site-heading">
              <h1></h1>
              
            </div>
          </div>
        </div>
      </div>
    </header>
  
    <!-- Main Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 ">
          <div class="post-preview">
            
              
              <div class="col-14">
                <h1 class="mt-10">Laporan Anda</h1>
                
                <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>         
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <?php echo e($report->kategori); ?>

                            <a href="/reports/<?php echo e($report->id); ?>" class="badge badge-info">detail</a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
              
            </a>
           
          </div>
          
          <!-- Pager -->
          <div class="clearfix">
            
          </div>
        </div>
      </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-8">
                <h1 class="mt-3">Form Laporan</h1>
                  <form method="POST" action="/reports">
                    <?php echo csrf_field(); ?>
                      
                      <div class="form-group">
                            <label for="kategori">kategori</label>
                                <select id="kategori" placeholder="Masukan kategori" class="form-control" name="kategori"  >
                                    <option value="" disabled selected hidden>Masukan Kategori</option>
                                    <option>Keamanan</option>
                                    <option>Kebersihan</option>
                                    <option>Fasilitas Umum</option>
                                </select>
                            </div>
                            
                      <div class="form-group">
                          <label for="lampiran">lampiran</label>
                            <input type="text" 
                                class="form-control <?php if ($errors->has('lampiran')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lampiran'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                    id="lampiran" placeholder="Masukkan lampiran" name="lampiran" value="<?php echo e(old('lampiran')); ?>">
                                        <?php if ($errors->has('lampiran')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lampiran'); ?>
                                            <div 
                                                class="invalid-feedback"><?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
                      
                      <div class="form-group">
                          <label for="deskripsi">Deskripsi</label>
                          <textarea class="form-control" id="Deskripsi" name="deskripsi" rows="3"></textarea>
                        </div>
                      
                      <div class="form-group">
                          <label for="tindakan">tindakan</label>
                              <select id="tindakan" placeholder="Masukan tindakan" class="form-control" name="tindakan"  >
                                  <option value="" disabled selected hidden>Masukan tindakan</option>
                                  <option>belum diproses</option>
                                  <option>Sedang diproses</option>
                                  <option>Terselesaikan</option>
                              </select>
                          </div>
                          
                      <button type="submit" class="btn btn-primary">Tambah Data!</button>
                    </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laporanBaru/resources/views/reports/index.blade.php ENDPATH**/ ?>